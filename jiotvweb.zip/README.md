
<p align="center"><img src="https://images.firstpost.com/wp-content/uploads/2020/07/jio-tvplus-1280.jpg" width="180" height="100"></p>

<h1 align='center'>✯ JɪᴏTV Pʟᴀʏ 2.2 ✯</h1>

<!-- DO NOT EDIT FILE AND ADD YOU NAME HERE AND PUBLISH -->
<!-- © 2021-22 TechieSneh -->

<h4 align='center'>📺 The PHP Script For Grabb Streaming Links and Play it , This Works Only on Android & Android TV Through LocalHost <br><br>🌟 Start This Repositry Befor Copying 😎<br>😠 Don't Remove Credits<br>Don't Edit This Script 😈<br><br>Put Your Own Credentials In This Script</h4>
<br>

<h2>😇 Features :</h2>

- HQ Streaming Free of Cost <br>
- Will Works In 250, 400, 600, 800, 1200(FEW NOT SUPPORT) in this Gives Qualities
- Web Play Supports
- Works on Phone or PC Browser Perfect


<br>
<h2>💖 NEW FEATURES :</h2>

- Search Feature Added<br>
1. Search by Channel Name e.g.Sony,Zee,Star ...
2. Search by Genre e.g.Entertainment,Kids,Movies,Music ...
3. Search by Language e.g.Hindi,Tamil,Kannada,Odia ... 


<br>
<h2>🍁 How To Use : </h2>

#### ♢ Method 1 :

• First Download This Application<br>
 - KSWEB PRO ( Php Web Server ) <br>

  ```py
  
https://dl1.apkhome.net/2019/6/KSWEB-3.93%20Pro.apk

  ```
  
  ```py

https://apkcow.com/ksweb-server-php-mysql-mod-apk/download/

  ```

• Then Download This Zip Files<br>
 - JioTV Zip <br> ( https://github.com/mitthu786/TS-JioTV/blob/main/jiotvweb.zip?raw=true ) <br>

• Locate & Extract all Files in LocalHost (Htdocs) Root Folder <br>
• Put Your E-Mail or Mobile Number without +91 & Password in below Link <br>

```py
http://localhost:8080/jiotvweb/login.php
```

• Open KSWEB App & Start The Server <br>
• Run login.php file for a first time <br>
• Open [JIOTV WEB] Below Link :

```py
http://localhost:8080/jiotvweb/
```
• Click above link in any Browser . You Will See all Jio Channels . <br>
• Click On Channel and Play <br>

#### ♢ Method 2 :

• In Player Put Links Format Like Below

  ```py
http://localhost:8080/jiotvweb/live.php?c=Channel_Name&q=Quality
  ```

```py
http://localhost:8080/jiotvweb/live.php?c=And_Pictures_HD&q=800
```
  
• <b>Depending on Your Server Change Links<br></b><br> 
• This Script is free for USE and Modify</b><br>

#### ♢ Method 3 :

• In Tivimate or OTT Navigator Player Put Links Format Like Below :<br> 

  ```py
http://localhost:8080/jiotvweb/playlist.php
  ```

  ```py
http://localhost:8080/jiotvweb/playlist.m3u
  ```

• FOR DIFFERENT QUALITY USE BELOW LINKS :<br> 

  ```py
http://localhost:8080/jiotvweb/localplaylists/jio240p.m3u
  ```

  ```py
http://localhost:8080/jiotvweb/localplaylists/jio360p.m3u
  ```
  
  ```py
http://localhost:8080/jiotvweb/localplaylists/jio480p.m3u
  ```

  ```py
http://localhost:8080/jiotvweb/localplaylists/jio720p.m3u
  ```

  ```py
http://localhost:8080/jiotvweb/localplaylists/jio1080p.m3u
  ```          
  
• Now Enjoy with your Jio Channels.</b><br>

<!-- DO NOT EDIT FILE AND ADD YOU NAME HERE AND PUBLISH -->
<!-- © 2021-22 TechieSneh -->

#### 😛 Generate ssoToken Here (HERE YOU GET DATA WITH OTP):

- For This You Need JioID Number and Password
- You Can Also get Data with OTP 

[Jio Login Page] (http://jiologin.unaux.com)
 
- `user` = Username / Mobile No.
- `pass` = Password

<br>
 

<h2>🚸 Warnings :</h2>

- This is Just For Educational Purpose
- DO NOT Sell this Script, This is 💯% Free

<h3>🤗 Meet Me : </h3>

• For any Support Join Our Group [Techie Sneh](https://t.me/techiesneh)<br>
• Or Contact at [techiesneh@protonmail.com](mailto:techiesneh@protonmail.com)

<br>


---
<h4 align='center'>© 2021-22 Techie Sneh</h4>

<!-- DO NOT REMOVE THIS CREDIT -->










