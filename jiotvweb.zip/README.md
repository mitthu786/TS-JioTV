
<p align="center"><img src="https://images.firstpost.com/wp-content/uploads/2020/07/jio-tvplus-1280.jpg" width="180" height="100"></p>

<h1 align='center'>✯ JɪᴏTV Pʟᴀʏ ✯</h1>

<!-- DO NOT EDIT FILE AND ADD YOU NAME HERE AND PUBLISH -->
<!-- © 2021 TechieSneh -->

<h4 align='center'>📺 The PHP Script For Grabb Streaming Links and Play it , This Works Only on Android & Android TV Through LocalHost <br><br>🌟 Start This Repositry Befor Copying 😎<br>😠 Don't Remove Credits<br>Don't Edit This Script 😈<br><br>Put Your Own Credentials In This Script</h4>
<br>

<h2>😇 Features :</h2>

- HQ Streaming Free of Cost <br>
- Will Works In 250, 400, 600, 800 in this Gives Qualities
- Web Play Supports
- Works on Phone or PC Browser Perfect


<br>
<h2>🍁 How To Use : </h2>

#### ♢ Method 1 :

• First Download This Application<br>
 - KSWEB PRO ( Php Web Server ) <br>

  ```py

https://apkdone.com/ksweb-server-php-mysql-apk/download

  ```

• Then Download This Zip Files<br>
 - JioTV Zip <br> ( https://github.com/mitthu786/TS-JioTV/blob/main/jiotvweb.zip?raw=true ) <br>

• Locate & Extract all Files in LocalHost (Htdocs) Root Folder <br>
• Put Your Mobile Number without +91 & Password in below Link <br>

```py
http://localhost:8080/jiotvweb/login.php?user=NUMBER&pass=PASSWORD
```

• Open KSWEB App & Start The Server <br>
• Run login.php file for a first time <br>
• Open [JIOTV WEB]
```py
http://localhost:8080/jiotvweb/
```
• Click above link in any Browser . You Will See all Jio Channels . <br>
• Click On Channel and Play <br>

#### ♢ Method 2 :

• In Player Put Links Format Like Below

  ```py
http://localhost/jiotvweb/live.php?c=Channel_Name&q=Quality
  ```

```py
http://localhost/jiotvweb/live.php?c=And_Pictures_HD&q=800
```
  
   • <b>Depnding on Your Server Change Links<br></b><br> 
   • This Script is free for USE and Modify</b><br>
   
#### 😛 Genrate ssoToken Here :

- For This You Need JioID Number and Password

[Jio Login Page] (http://jiologin.unaux.com)
 
- `user` = Username / Mobile No.
- `pass` = Password

<br>
 

<h2>🚸 Warnings :</h2>

- This is Just For Educational Purpose
- DO NOT Sell this Script, This is 💯% Free

<h3>🤗 Meet Me : </h3>

• For any Support Join Our Group [Techie Sneh](https://t.me/techiesneh)<br>
• Or Contact at [techiesneh@protonmail.com](mailto:techiesneh@protonmail.com)

<br>


---
<h4 align='center'>© 2022 Techie Sneh</h4>

<!-- DO NOT REMOVE THIS CREDIT 🤬 🤬 -->










