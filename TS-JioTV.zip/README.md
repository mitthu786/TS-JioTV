<p align='center'><img src="https://i.ibb.co/BcjC6R8/jiotv.png" width="120"></p>

<!--
* Copyright 2021-24 SnehTV, Inc.
* Licensed under MIT (https://github.com/mitthu786/TS-JioTV/blob/main/LICENSE)
* Created By : TechieSneh
-->

<h4 align='center'>📺 The PHP Script For Grab Streaming Links and Play it ,</br> This Works Only on Android & Android TV
Through LocalHost </br></br>🌟 Star This Repository Before Forking 😎</br>Don't Edit This Script
😈</h4>
</br>

<h3>♻️ JOIN FOR UPDATES :</h3>

- JOIN OUR TELEGRAM CHANNEL
- https://tsneh.vercel.app/ts-tg

<h3>😇 SCRIPT FEATURES :</h3>

- New UI & Design
- 7 Days Catchup Added
- OTP Login Added
- Dropdown Filters Updated
- Multi Audio Stream Support
- Web Play with Quality Change Supports
- Works on Mobile, AndroidTV or PC Browser Perfect

<h3>💖 PLAYER FEATURES :</h3>

- Search Feature Added</br>

  1. 🔍 SEARCH BY CHANNEL NAME

  ```
  e.g.  Sony,Zee,Star ...
  ```

  2. 🔍 SEARCH BY GENRE

  ```
  e.g.  Entertainment,Kids,Movies,Music ...
  ```

  3. 🔍 SEARCH BY LANGUAGE

  ```
  e.g.  Hindi,Tamil,Kannada,Odia ...
  ```

<h3>⏯️ 7-DAYS CATCHUP :</h3>

- Catchup Added</br>

</br>
<h3>📸 MOBILE SHOTS : </h3>
<p align="left">
  <img src="https://i.ibb.co/bL3x1f9/1.png" alt="mob-home" width="120">
  <img src="https://i.ibb.co/dGMrpdf/2.png" alt="mob-7-Days" width="120">
</p>

<p align="left">
  <img src="https://i.ibb.co/b72rZ1m/3.png" alt="mob-Catchup" width="120">
  <img src="https://i.ibb.co/nDmthvB/4.png" alt="mob-Catchup-Play" width="120">
</p>

<h3>📸 PC WEB SHOTS : </h3>

<img src="https://i.ibb.co/7tJd9Rb/11.png" alt="home" width="300" height="150"></br>
<img src="https://i.ibb.co/xYJNzw3/play.png" width="300" height="150"></br>
<img src="https://i.ibb.co/P5RTwNN/12.png" alt="Catchup7-Days" width="300" height="150"></br>
<img src="https://i.ibb.co/0qNGkdg/13.png" alt="Catchup" width="300" height="150"></br>
<img src="https://i.ibb.co/tbzzwrq/Catchup-Play.png" alt="Catchup-Play" width="300" height="150"></br>

</br>

<h2>🍁 HOW TO USE : </h2>

### 🔐 Installation :

### 🅰️ First Download This Application ( PHP WEB SERVER )

1. `KSWEB PRO v3.987 for Mobile`

   ```
   https://tsneh.vercel.app/ksweb_3.987.apk
   ```

2. `XAMPP for Windows (PC)`

   ```
   https://www.apachefriends.org/download.html
   ```

### 🅱️ Then Download This Zip File

- [TS-JioTV Zip](https://tsnehcors.mitthu.workers.dev/?https://github.com/mitthu786/TS-JioTV/blob/main/TS-JioTV.zip?raw=true) </br>

1. Locate & Extract all Files in LocalHost `Htdocs` Root Folder
2. Open KSWEB app `Choose Nginx Server` & Then start the server
3. Open Browser & type `http://localhost/TS-JioTV/`
4. Now Open `TS-JioTV` Below Link :

   ```
   http://localhost:8000/TS-JioTV/
   ```

5. First Login with your credentials
6. Now, You Will See all Jio Channels
7. Click on Channel and Play. </br>

## ▶️ PlayList Methods :

• In Tivimate or OTT Navigator Player Put Links Format Like Below :

```
http://localhost:8080/TS-JioTV/app/tsjio_playlist.m3u
```

• Hurrah !! Now Play & Enjoy with your Jio Channels .

<!--
* Copyright 2021-24 SnehTV, Inc.
* Licensed under MIT (https://github.com/mitthu786/TS-JioTV/blob/main/LICENSE)
* Created By : TechieSneh
-->

### 😛 GENERATE CREDS.JSON (OTP USERS):

1. ✍️ FOR SSO TOKEN : [JioLogin](http://jiologin.unaux.com)
2. For This You Need JioID Number and Password
3. You Can Also get Data with OTP

   - `user` = Username / Mobile No.
   - `pass` = Password

<h3>🚸 WARNINGS :</h3>

- This is Just For Educational Purpose
- Don't Sell this Script, This is 💯% Free

<h3>🤗 CONTACT US : </h3>

- TELEGRAM CHANNEL [JOIN NOW](https://tsneh.vercel.app/ts-tg)
- FOR ANY QUERY CONTACT US ON [PROTON-MAIL](mailto:techiesneh@protonmail.com)

</br>

---

<h4 align='center'>© 2021-24 Techie Sneh</h4>

<!-- DO NOT REMOVE THIS CREDIT -->
<!-- © 2021-24 TechieSneh -->
