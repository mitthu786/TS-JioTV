<p align='center'><img src="https://i.ibb.co/BcjC6R8/jiotv.png" width="120"></p>

<!--
* Copyright 2021-24 SnehTV, Inc.
* Licensed under MIT (https://github.com/mitthu786/TS-JioTV/blob/main/LICENSE)
* Created By : TechieSneh
-->

<h4 align='center'>📺 The PHP Script For Grab Streaming Links and Play it ,</br> This Works Only on Android & Android TV
Through LocalHost </br></br>🌟 Star This Repository Before Forking 😎</br>Don't Edit This Script
😈</h4>
</br>

<h3>♻️ JOIN FOR UPDATES :</h3>

- JOIN OUR TELEGRAM CHANNEL
- https://tsneh.vercel.app/ts-tg

<h3>😇 SCRIPT FEATURES :</h3>

- New UI & Design
- Dropdown Filters Added
- Will Works In All Qualities
- Multi Audio Stream Support
- Web Play with Quality Change Supports
- Works on Mobile, AndroidTV or PC Browser Perfect

<h3>💖 PLAYER FEATURES :</h3>

- Search Feature Added</br>

  1. 🔍 SEARCH BY CHANNEL NAME

  ```
  e.g.  Sony,Zee,Star ...
  ```

  2. 🔍 SEARCH BY GENRE

  ```
  e.g.  Entertainment,Kids,Movies,Music ...
  ```

  3. 🔍 SEARCH BY LANGUAGE

  ```
  e.g.  Hindi,Tamil,Kannada,Odia ...
  ```

<h3>⏯️ 7-DAYS CATCHUP :</h3>

- Catchup Added</br>

</br>
<h3>📸 MOBILE SHOTS : </h3>

<img src="https://i.ibb.co/9hGqtLD/mob-home.png" alt="mob-home" width="120">
<img src="https://i.ibb.co/D9gWPB1/mob-7-Days.png" alt="mob-7-Days" width="120">
<img src="https://i.ibb.co/p0Qk4HZ/mob-Catchup.png" alt="mob-Catchup" width="120">
<img src="https://i.ibb.co/Y2xXwdF/mob-Catchup-Play.png" alt="mob-Catchup-Play" width="120">

<h3>📸 PC WEB SHOTS : </h3>

<img src="https://i.ibb.co/RNSj9t2/home.png" alt="home" width="300" height="150"></br>
<img src="https://i.ibb.co/xYJNzw3/play.png" width="300" height="150"></br>
<img src="https://i.ibb.co/F66ckTm/Catchup7-Days.png" alt="Catchup7-Days" width="300" height="150"></br>
<img src="https://i.ibb.co/PTbsgys/Catchup.png" alt="Catchup" width="300" height="150"></br>
<img src="https://i.ibb.co/tbzzwrq/Catchup-Play.png" alt="Catchup-Play" width="300" height="150"></br>

</br>

<h2>🍁 HOW TO USE : </h2>

### 🔐 Installation :

### 🅰️ First Download This Application

1. `KSWEB PRO` ( Php Web Server )

```
https://dl1.apkhome.net/2019/6/KSWEB-3.93%20Pro.apk
```

```
https://oceanofapk.com/ksweb-server-php-mysql-v3-961-pro-apk-free-download/
```

```
https://s3.dlandroid.com/apps/KSWEB-server[dlandroid.com].apk
```

### 🅱️ Then Download This Zip File

- [TS-JioTV Zip](https://tsnehcors.mitthu.workers.dev/?https://github.com/mitthu786/TS-JioTV/blob/main/TS-JioTV.zip?raw=true) </br>

1. Locate & Extract all Files in LocalHost `Htdocs` Root Folder. </br>
2. Open KSWEB app & start the server. </br>
3. Now Open `TS-JioTV` Below Link :

```
http://localhost:8080/TS-JioTV/
```

4. First Login with your credentials.
5. Now, You Will See all Jio Channels. </br>
6. Click on Channel and Play. </br>

## ▶️ PlayList Methods :

• In Tivimate or OTT Navigator Player Put Links Format Like Below :</br>

```
http://localhost:8080/TS-JioTV/app/playlist.php
```

• Hurrah !! Now Play & Enjoy with your Jio Channels .

<!--
* Copyright 2021-24 SnehTV, Inc.
* Licensed under MIT (https://github.com/mitthu786/TS-JioTV/blob/main/LICENSE)
* Created By : TechieSneh
-->

### 😛 GENERATE CREDS.JSON (OTP USERS):

1. ✍️ FOR SSO TOKEN : [JioLogin](http://jiologin.unaux.com)
2. For This You Need JioID Number and Password
3. You Can Also get Data with OTP

   - `user` = Username / Mobile No.
   - `pass` = Password

<h3>🚸 WARNINGS :</h3>

- This is Just For Educational Purpose
- Don't Sell this Script, This is 💯% Free

<h3>🤗 CONTACT US : </h3>

- TELEGRAM CHANNEL [JOIN NOW](https://tsneh.vercel.app/ts-tg)
- FOR ANY QUERY CONTACT US ON [PROTON-MAIL](mailto:techiesneh@protonmail.com)

</br>

---

<h4 align='center'>© 2021-24 Techie Sneh</h4>

<!-- DO NOT REMOVE THIS CREDIT -->
<!-- © 2021-24 TechieSneh -->
