<h1 align='center'>✯ JɪᴏTV+ <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Jio_TV_logo.svg/1200px-Jio_TV_logo.svg.png" width="40" height="40"> Pʟᴀʏ  ✯</h1>

<!--
* Copyright 2021-2023 SnehTV, Inc.
* Licensed under MIT (https://github.com/mitthu786/TS-JioTV/blob/main/LICENSE)
* Created By : TechieSneh
-->

<h4 align='center'>📺 The PHP Script For Grab Streaming Links and Play it ,<br> This Works Only on Android & Android TV
Through LocalHost <br><br>🌟 Star This Repository Before Copying 😎<br>Don't Edit This Script
😈<br><br>Login With Your Own Credentials In This Script</h4>
<br>

<h3>♻️ JOIN FOR UPDATES :</h3>

- JOIN TELEGRAM CHANNEL
- https://bit.ly/3QwIvIC

<h3>😇 SCRIPT FEATURES :</h3>

- HQ Streaming Free of Cost
- Will Works In All Qualities
- Web Play with Quality Change Supports
- Works on Mobile, AndroidTV or PC Browser Perfect

<h3>💖 PLAYER FEATURES :</h3>

- Search Feature Added<br>

1. 🔍 SEARCH BY CHANNEL NAME

```
e.g.  Sony,Zee,Star ...
```

2. 🔍 SEARCH BY GENRE

```
e.g.  Entertainment,Kids,Movies,Music ...
```

3. 🔍 SEARCH BY LANGUAGE

```
e.g.  Hindi,Tamil,Kannada,Odia ...
```

<br>

<h3>📸 SCREENSHOTS : </h3>

<img src="https://i.ibb.co/brMR0c4/main.png" width="400" height="200">

<br>

<img src="https://i.ibb.co/Dz4Nhxm/play.png" width="400" height="200">

<br>

<h2>🍁 HOW TO USE : </h2>

#### ♢ Login Method 1 :

1. First Download This Application<br>

- KSWEB PRO ( Php Web Server ) <br>

```py
https://dl1.apkhome.net/2019/6/KSWEB-3.93%20Pro.apk
```

```py
https://oceanofapk.com/ksweb-server-php-mysql-v3-961-pro-apk-free-download/
```

```py
https://s3.dlandroid.com/apps/KSWEB-server[dlandroid.com].apk
```

2.  Then Download This Zip File<br>

- [TS-JioTV Zip](https://tsnehcors.mitthu.workers.dev/?https://github.com/mitthu786/TS-JioTV/blob/main/TS-JioTV.zip?raw=true) <br>

1. Locate & Extract all Files in LocalHost (Htdocs) Root Folder <br>
2. Open KSWEB App & Start The Server <br>
3. Run login.php file for a first time <br>
4. Put Your E-Mail or Mobile Number without +91 & Password in below Link <br>

```py
http://localhost:8080/TS-JioTV/login.php
```

7. Now Open [JIOTV WEB] Below Link :

```py
http://localhost:8080/TS-JioTV/
```

8. Click above link in any Browser . You Will See all Jio Channels . <br>
9. Click On Channel and Play <br>

#### ♢ Login Method 2 :

- Follow Above Instructions First & Then Try To Login with this Method.

1. Put Your E-Mail or Mobile Number without +91 & Password in Below Link <br>

```py
http://localhost:8080/TS-JioTV/login_direct.php?user=`NUMBER`&pass=`PASSWORD`
```

2. Now Open [JIOTV WEB] Below Link :

```py
http://localhost:8080/TS-JioTV/
```

3. Click above link in any Browser . You Will See all Jio Channels . <br>
4. Click On Channel and Play <br>

#### ♢ Play Methods :

• In Tivimate or OTT Navigator Player Put Links Format Like Below :<br>

```py
http://localhost:8080/TS-JioTV/playlist.php
```

• Hurrah !! Now Play & Enjoy with your Jio Channels .

<!--
* Copyright 2021-2023 SnehTV, Inc.
* Licensed under MIT (https://github.com/mitthu786/TS-JioTV/blob/main/LICENSE)
* Created By : TechieSneh
-->

### 😛 Generate ssoToken Here (HERE YOU GET DATA WITH OTP):

1. ✍️ FOR SSO TOKEN : [JioLogin](http://jiologin.unaux.com)
2. For This You Need JioID Number and Password
3. You Can Also get Data with OTP

- `user` = Username / Mobile No.
- `pass` = Password

<h3>🚸 WARNINGS :</h3>

- This is Just For Educational Purpose
- Don't Sell this Script, This is 💯% Free

<h3>🤗 CONTACT US : </h3>

- TELEGRAM CHANNEL [JOIN NOW](https://bit.ly/3QwIvIC)
- FOR ANY QUERY CONTACT US ON [ProtonMail](mailto:techiesneh@protonmail.com)

<br>

---

<h4 align='center'>© 2021-23 Techie Sneh</h4>

<!-- DO NOT REMOVE THIS CREDIT -->
<!-- © 2021-23 TechieSneh -->
